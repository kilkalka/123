package org.gradle.sample.app;

class MessageUtils {
    public static String getMessage() {
        return "Hello,      World!";
    }
}
