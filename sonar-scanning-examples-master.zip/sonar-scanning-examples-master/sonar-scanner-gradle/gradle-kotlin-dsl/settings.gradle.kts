// Noncompliant - kotlin:6625 "rootProject.name" should always be present in Gradle settings
//rootProject.name = "gradle-kotlin-dsl"
