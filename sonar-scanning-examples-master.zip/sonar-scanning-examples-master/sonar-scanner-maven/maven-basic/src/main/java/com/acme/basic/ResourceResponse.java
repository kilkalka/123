package com.acme.basic;

public class ResourceResponse<T> {
}
